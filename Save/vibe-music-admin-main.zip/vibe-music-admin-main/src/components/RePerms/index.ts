import perms from "./src/perms";

const Perms = perms;

export { Perms };
