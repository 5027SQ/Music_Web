<template>
    <el-card shadow="hover" class="dashboard-card">
      <h2 class="title">欢迎进入音乐后台管理系统</h2>
      <p class="desc">请从左侧菜单进入管理模块。</p>
    </el-card>
  </template>
  
  <style scoped>
  .dashboard-card {
    background: #fffaf1;
    border-radius: 12px;
  }
  .title {
    font-size: 18px;
    font-weight: 600;
    color: #6b4f2a;
  }
  .desc {
    margin-top: 8px;
    color: #8c6b3f;
  }
  </style>