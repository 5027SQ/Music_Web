package com.example.music.domain.dto;

import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class SongUpdateReq {
    @Size(max = 200)
    private String title;

    @Size(max = 200)
    private String artist;

    @Size(max = 200)
    private String album;

    @Size(max = 500)
    private String coverUrl;

    @Size(max = 500)
    private String audioUrl;

    private Integer durationSec;

    private Integer status; // 1=正常 0=下架（可选）
}
