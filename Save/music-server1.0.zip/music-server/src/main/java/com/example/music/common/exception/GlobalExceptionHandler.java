package com.example.music.common.exception;

import com.example.music.common.result.Result;
import jakarta.validation.ConstraintViolationException;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(MaxUploadSizeExceededException.class)
    public Result<Void> maxSize(MaxUploadSizeExceededException e) {
        return Result.fail("file too large, please upload a smaller file or increase max-file-size");
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public Result<Void> notReadable(HttpMessageNotReadableException e) {
        e.printStackTrace();
        String msg = e.getMostSpecificCause() != null ? e.getMostSpecificCause().getMessage() : e.getMessage();
        return Result.fail("bad json: " + msg);
    }

    @ExceptionHandler(BizException.class)
    public Result<Void> biz(BizException e) {
        return Result.fail(e.getMessage());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Result<Void> valid(MethodArgumentNotValidException e) {
        String msg = e.getBindingResult().getFieldErrors().stream()
                .findFirst()
                .map(fe -> fe.getField() + " " + fe.getDefaultMessage())
                .orElse("validation error");
        return Result.fail(msg);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public Result<Void> constraint(ConstraintViolationException e) {
        return Result.fail(e.getMessage());
    }

    @ExceptionHandler(Exception.class)
    public Result<Void> unknown(Exception e) {
        e.printStackTrace();
        return Result.fail("server error: " + e.getClass().getSimpleName());
    }
}
