package com.example.music.security;

import com.example.music.common.result.Result;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.Claims;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.HttpMethod;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.servlet.HandlerInterceptor;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.List;

//鉴权拦截器（JWT + Redis 校验 token）
public class LoginInterceptor implements HandlerInterceptor {

    private final StringRedisTemplate redisTemplate;
    private final Key key;
    private final List<String> whitelist;
    private final AntPathMatcher matcher = new AntPathMatcher();
    private final ObjectMapper om = new ObjectMapper();

    public LoginInterceptor(StringRedisTemplate redisTemplate, Key key, List<String> whitelist) {
        this.redisTemplate = redisTemplate;
        this.key = key;
        this.whitelist = whitelist;
    }

    private boolean isWhitelisted(String path) {
        for (String p : whitelist) {
            if (matcher.match(p, path)) return true;
        }
        return false;
    }

    private void writeJson(HttpServletResponse resp, int httpCode, Result<?> body) throws IOException {
        resp.setStatus(httpCode);
        resp.setCharacterEncoding(StandardCharsets.UTF_8.name());
        resp.setContentType("application/json");
        resp.getWriter().write(om.writeValueAsString(body));
    }

    @Override
    public boolean preHandle(HttpServletRequest req, HttpServletResponse resp, Object handler) throws Exception {
        String path = req.getRequestURI();

        // 预检请求放行
        if (HttpMethod.OPTIONS.matches(req.getMethod())) return true;

        // 白名单放行
        if (isWhitelisted(path)) return true;

        String auth = req.getHeader("Authorization");
        if (auth == null || !auth.startsWith("Bearer ")) {
            writeJson(resp, 401, Result.fail("missing token"));
            return false;
        }

        String token = auth.substring("Bearer ".length()).trim();
        if (token.isEmpty()) {
            writeJson(resp, 401, Result.fail("missing token"));
            return false;
        }

        // Redis 校验 token 是否仍有效（支持登出/踢下线）
        String redisKey = "auth:token:" + token;
        Boolean exists = redisTemplate.hasKey(redisKey);
        if (exists == null || !exists) {
            writeJson(resp, 401, Result.fail("token expired or logged out"));
            return false;
        }

        try {
            Claims claims = JwtUtil.parse(key, token);
            AuthContext.set(claims);
            return true;
        } catch (Exception e) {
            writeJson(resp, 401, Result.fail("invalid token"));
            return false;
        }
    }

    @Override
    public void afterCompletion(HttpServletRequest req, HttpServletResponse resp, Object handler, Exception ex) {
        AuthContext.clear();
    }
}
