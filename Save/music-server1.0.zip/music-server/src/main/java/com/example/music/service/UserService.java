package com.example.music.service;

import com.example.music.domain.dto.LoginReq;
import com.example.music.domain.dto.RegisterReq;
import com.example.music.domain.vo.LoginVO;
import com.example.music.domain.vo.UserMeVO;

//注册/登录/当前用户/登出
public interface UserService {
    void register(RegisterReq req);
    LoginVO login(LoginReq req);
    UserMeVO me();
    void logout(String token);
}
