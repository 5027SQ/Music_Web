package com.example.music.common.exception;

public class BizException extends RuntimeException {
    public BizException(String message) {
        super(message);
    }
}
