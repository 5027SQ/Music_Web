<script setup lang="ts">
import DefaultLayout from '@/layout/index.vue'
</script>

<template>
  <DefaultLayout />
</template>
