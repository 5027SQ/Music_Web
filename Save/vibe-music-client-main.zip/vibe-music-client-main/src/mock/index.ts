// 默认数据
export const trackListData = [
]

export const defaultSong = {
    title: '未选择歌曲',
    artist: '未知歌手',
    cover: new URL(`@/assets/default_album.jpg`, import.meta.url).href,
}