export type PlayMode = 'loop' | 'order' | 'shuffle' | 'single'
